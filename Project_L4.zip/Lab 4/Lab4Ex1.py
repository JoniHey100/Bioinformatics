# -*- coding: utf-8 -*-
"""
Created on Thu Oct 23 14:30:44 2025

@author: ionat
"""
from typing import Tuple, List

# --- Genetic code (RNA codons) ---
# One-letter amino-acid codes; 'Stop' for stop codons.
GENETIC_CODE_1L = {
    # U-row
    "UUU": "F", "UUC": "F", "UUA": "L", "UUG": "L",
    "UCU": "S", "UCC": "S", "UCA": "S", "UCG": "S",
    "UAU": "Y", "UAC": "Y", "UAA": "Stop", "UAG": "Stop",
    "UGU": "C", "UGC": "C", "UGA": "Stop", "UGG": "W",
    # C-row
    "CUU": "L", "CUC": "L", "CUA": "L", "CUG": "L",
    "CCU": "P", "CCC": "P", "CCA": "P", "CCG": "P",
    "CAU": "H", "CAC": "H", "CAA": "Q", "CAG": "Q",
    "CGU": "R", "CGC": "R", "CGA": "R", "CGG": "R",
    # A-row
    "AUU": "I", "AUC": "I", "AUA": "I", "AUG": "M",
    "ACU": "T", "ACC": "T", "ACA": "T", "ACG": "T",
    "AAU": "N", "AAC": "N", "AAA": "K", "AAG": "K",
    "AGU": "S", "AGC": "S", "AGA": "R", "AGG": "R",
    # G-row
    "GUU": "V", "GUC": "V", "GUA": "V", "GUG": "V",
    "GCU": "A", "GCC": "A", "GCA": "A", "GCG": "A",
    "GAU": "D", "GAC": "D", "GAA": "E", "GAG": "E",
    "GGU": "G", "GGC": "G", "GGA": "G", "GGG": "G",
}

AA_1L_TO_NAME = {
    "F": "Phe", "L": "Leu", "S": "Ser", "Y": "Tyr", "C": "Cys", "W": "Trp",
    "P": "Pro", "H": "His", "Q": "Gln", "R": "Arg", "I": "Ile", "M": "Met",
    "T": "Thr", "N": "Asn", "K": "Lys", "V": "Val", "A": "Ala", "D": "Asp",
    "E": "Glu", "G": "Gly"
}

STOP_CODONS = {"UAA", "UAG", "UGA"}


def read_sequence_maybe_fasta(text: str) -> str:
    """Accepts a raw string (FASTA or plain) and returns the concatenated DNA sequence (A/C/G/T only)."""
    lines = [ln.strip() for ln in text.strip().splitlines() if ln.strip()]
    if not lines:
        return ""
    if lines[0].startswith(">"):
        seq_lines = lines[1:]
    else:
        seq_lines = lines
    dna = "".join(seq_lines).upper().replace(" ", "")
    # keep only A/C/G/T; if others present, raise
    for ch in dna:
        if ch not in "ACGT":
            raise ValueError(f"Invalid character in DNA: '{ch}'. Allowed: A/C/G/T.")
    return dna


def dna_to_rna(dna: str) -> str:
    """DNA (A/C/G/T) -> RNA (A/C/G/U)."""
    return dna.replace("T", "U")


def translate_coding_region(rna: str) -> Tuple[str, List[str], int, int]:
    start = rna.find("AUG")
    if start == -1:
        raise ValueError("No AUG start codon found in the RNA sequence.")

    aa_codes = []
    names = []
    i = start
    while i + 3 <= len(rna):
        codon = rna[i:i+3]
        if codon in STOP_CODONS:
            i += 3  # include stop in covered region
            break
        aa = GENETIC_CODE_1L.get(codon, None)
        if aa is None:
            # Shouldn't happen if input is A/C/G/U only, but keep safe.
            raise ValueError(f"Unknown codon: {codon}")
        if aa == "Stop":  # redundant guard
            i += 3
            break
        aa_codes.append(aa)
        names.append(AA_1L_TO_NAME[aa])
        i += 3

    return "".join(aa_codes), names, start, i


def pretty_translate_from_dna(dna_text: str) -> None:
    try:
        dna = read_sequence_maybe_fasta(dna_text)
        rna = dna_to_rna(dna)
        protein_1L, protein_names, start, stop = translate_coding_region(rna)

        print("Input DNA:")
        print(dna)
        print("\nmRNA (T→U):")
        print(rna)
    except Exception as e:
        print(f"Error: {e}")


# ---------------- Demo / simple UI ----------------
if __name__ == "__main__":
    dna = "AAACTGCCCATGAAATTTGCCGCTGCTGATCTTTTAAACCTAA"
    pretty_translate_from_dna(dna)
