# codon_compare.py  (with charts + comparison + top AAs)
from collections import Counter, defaultdict
from itertools import product
from pathlib import Path
import csv
import matplotlib.pyplot as plt

# ---------- Configuration ----------
FILE_A = "covid.fasta"       # SARS-CoV-2 genome
FILE_B = "influenza.fasta"   # Influenza genome
OUTPUT_CSV = "codon_compare.csv"
COVID_PLOT = "covid_top10.png"
FLU_PLOT   = "influenza_top10.png"

# ---------- Genetic code (RNA codons -> AA 1-letter) ----------
GENETIC_CODE_1L = {
    # U-row
    "UUU":"F","UUC":"F","UUA":"L","UUG":"L",
    "UCU":"S","UCC":"S","UCA":"S","UCG":"S",
    "UAU":"Y","UAC":"Y","UAA":"Stop","UAG":"Stop",
    "UGU":"C","UGC":"C","UGA":"Stop","UGG":"W",
    # C-row
    "CUU":"L","CUC":"L","CUA":"L","CUG":"L",
    "CCU":"P","CCC":"P","CCA":"P","CCG":"P",
    "CAU":"H","CAC":"H","CAA":"Q","CAG":"Q",
    "CGU":"R","CGC":"R","CGA":"R","CGG":"R",
    # A-row
    "AUU":"I","AUC":"I","AUA":"I","AUG":"M",
    "ACU":"T","ACC":"T","ACA":"T","ACG":"T",
    "AAU":"N","AAC":"N","AAA":"K","AAG":"K",
    "AGU":"S","AGC":"S","AGA":"R","AGG":"R",
    # G-row
    "GUU":"V","GUC":"V","GUA":"V","GUG":"V",
    "GCU":"A","GCC":"A","GCA":"A","GCG":"A",
    "GAU":"D","GAC":"D","GAA":"E","GAG":"E",
    "GGU":"G","GGC":"G","GGA":"G","GGG":"G",
}
STOP_CODONS = {"UAA","UAG","UGA"}

# ---------- Helpers ----------
CODONS64 = ["".join(x) for x in product("ACGT", repeat=3)]

def read_fasta_sequence(path: str) -> str:
    seq = []
    with open(path, "r", encoding="utf-8") as f:
        for ln in f:
            ln = ln.strip()
            if not ln or ln.startswith(">"):
                continue
            seq.append(ln)
    return "".join(seq).upper().replace("U", "T")  # normalize any RNA to DNA

def sanitize_dna(dna: str) -> str:
    return "".join(ch for ch in dna if ch in "ACGT")

def count_codons_in_frame(dna: str, frame: int) -> Counter:
    c = Counter()
    for i in range(frame, len(dna) - 2, 3):
        codon = dna[i:i+3]
        if len(codon) == 3 and all(b in "ACGT" for b in codon):
            c[codon] += 1
    return c

def counts_all_frames(dna: str):
    frames = [count_codons_in_frame(dna, f) for f in (0,1,2)]
    total = sum(frames, Counter())
    return frames, total

def to_freq(counts: Counter):
    total = sum(counts.values())
    freqs = {}
    for codon in CODONS64:
        freqs[codon] = (counts.get(codon, 0) / total) if total > 0 else 0.0
    return freqs, total

def diff_report(freqA: dict, freqB: dict, top=10):
    diffs = []
    for codon in CODONS64:
        d = freqA[codon] - freqB[codon]
        diffs.append((codon, d, freqA[codon], freqB[codon]))
    diffs.sort(key=lambda x: abs(x[1]), reverse=True)
    return diffs[:top]

# ---- plotting ----
def plot_top10(freq: dict, title: str, outfile: str):
    top10 = sorted(freq.items(), key=lambda kv: kv[1], reverse=True)[:10]
    codons = [c for c, _ in top10]
    vals   = [v for _, v in top10]
    plt.figure(figsize=(8, 4), dpi=120)
    plt.bar(codons, vals)
    plt.title(title)
    plt.ylabel("Frequency")
    plt.xlabel("Codon")
    plt.xticks(rotation=0)
    plt.tight_layout()
    plt.savefig(outfile)
    plt.show()

# ---- NEW: AA-level aggregation ----
def amino_acid_freq_from_codon_counts(counts: Counter):
    """Map 64 DNA codons to AA (via RNA) and return AA frequency dict (stops excluded)."""
    total_codons = sum(counts.values())
    aa_counts = defaultdict(int)
    aa_total = 0
    for dna_codon, n in counts.items():
        rna_codon = dna_codon.replace("T", "U")
        aa = GENETIC_CODE_1L.get(rna_codon)
        if aa is None or aa in STOP_CODONS or aa == "Stop":
            continue
        aa_counts[aa] += n
        aa_total += n
    aa_freq = {aa: (aa_counts[aa] / aa_total) if aa_total else 0.0 for aa in aa_counts}
    return aa_counts, aa_freq, aa_total

def top_n(d: dict, n=10):
    return sorted(d.items(), key=lambda kv: kv[1], reverse=True)[:n]

# ---------- Main workflow ----------
def compare_two_fastas(file_a=FILE_A, file_b=FILE_B, out_csv=OUTPUT_CSV):
    pA, pB = Path(file_a), Path(file_b)
    if not pA.exists() or not pB.exists():
        raise FileNotFoundError(f"Could not find both files: {pA} and {pB}")

    dnaA = sanitize_dna(read_fasta_sequence(pA))
    dnaB = sanitize_dna(read_fasta_sequence(pB))

    framesA, totalA = counts_all_frames(dnaA)
    framesB, totalB = counts_all_frames(dnaB)

    # Combined over the 3 reading frames (non-overlapping)
    freqA, ncodA = to_freq(totalA)
    freqB, ncodB = to_freq(totalB)

    # Write CSV table
    with open(out_csv, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["codon","covid_count","covid_freq","influenza_count","influenza_freq","delta_freq(A-B)"])
        for codon in CODONS64:
            ca = totalA.get(codon, 0); cb = totalB.get(codon, 0)
            w.writerow([codon, ca, f"{freqA[codon]:.6f}", cb, f"{freqB[codon]:.6f}",
                        f"{(freqA[codon]-freqB[codon]):.6f}"])

    # Console summary
    print("=== Input ===")
    print(f"File A: {pA.name}  | length (A/C/G/T kept): {len(dnaA):,}")
    print(f"File B: {pB.name}  | length (A/C/G/T kept): {len(dnaB):,}\n")

    print("=== Codon totals (sum of 3 frames, non-overlapping) ===")
    print(f"Total codons A (covid):     {ncodA:,}")
    print(f"Total codons B (influenza): {ncodB:,}\n")

    for idx, (fa, fb) in enumerate(zip(framesA, framesB)):
        na = sum(fa.values()); nb = sum(fb.values())
        print(f"Frame {idx}: codons A={na:,} | B={nb:,}")

    print("\n=== Top 10 codon frequency differences (combined) ===")
    topdiff = diff_report(freqA, freqB, top=10)
    print("codon  delta(A-B)   A_freq     B_freq")
    for codon, d, fa, fb in topdiff:
        print(f"{codon:>4}   {d:+.4f}    {fa:.4f}    {fb:.4f}")

    print(f"\nWrote full table to: {out_csv}")

    # ---- Charts (A & B from earlier step) ----
    plot_top10(freqA, "Top 10 Codons (COVID-19)", COVID_PLOT)
    plot_top10(freqB, "Top 10 Codons (Influenza)", FLU_PLOT)
    print(f"Saved figures: {COVID_PLOT}, {FLU_PLOT}")

    # ---- C) Cross-genome comparison of most frequent codons ----
    top10_A = [c for c,_ in top_n(freqA, 10)]
    top10_B = [c for c,_ in top_n(freqB, 10)]
    overlap = [c for c in top10_A if c in top10_B]

    # Combined profile (mean of the two freqs), then top 10 overall
    combined = {c: (freqA[c] + freqB[c]) / 2.0 for c in CODONS64}
    top10_combined = top_n(combined, 10)

    print("\n=== (C) Most frequent codons across both genomes ===")
    print("Overlap of top-10 lists (A ∩ B):", ", ".join(overlap) if overlap else "(none)")
    print("Top-10 by combined average frequency (A & B mean):")
    for codon, val in top10_combined:
        print(f"{codon}: {val:.4f}  (A={freqA[codon]:.4f}, B={freqB[codon]:.4f})")

    # ---- D) Top 3 amino acids from each genome (stops excluded) ----
    aa_counts_A, aa_freq_A, _ = amino_acid_freq_from_codon_counts(totalA)
    aa_counts_B, aa_freq_B, _ = amino_acid_freq_from_codon_counts(totalB)
    top3_AA_A = top_n(aa_freq_A, 3)
    top3_AA_B = top_n(aa_freq_B, 3)

    print("\n=== (D) Top 3 amino acids from each genome (by frequency) ===")
    print("COVID-19 : ", ", ".join([f"{aa} ({freq:.3f})" for aa, freq in top3_AA_A]))
    print("Influenza : ", ", ".join([f"{aa} ({freq:.3f})" for aa, freq in top3_AA_B]))

if __name__ == "__main__":
    compare_two_fastas()
