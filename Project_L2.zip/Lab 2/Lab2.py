from itertools import product
from collections import Counter

S = "TACGTGCGCGCGAGCTATCTACTGACTTACGACTAGTGTAGCTGCATCATCGATCGA"
ALPHABET = "ACGT"

def all_kmers(k: int):
    return ["".join(p) for p in product(ALPHABET, repeat=k)]

def kmer_percentages(seq: str, k: int):
    counts = Counter(seq[i:i+k] for i in range(len(seq) - k + 1))
    total = len(seq) - k + 1  
    result = []
    for km in all_kmers(k):
        pct = (counts.get(km, 0) / total) * 100
        result.append((km, pct))
    return total, result

for k in (2, 3):
    total, result = kmer_percentages(S, k)
    print(f"\n{k}-mers: total windows = {total}")
    for km, pct in result:
        print(f"{km}\t{pct:.2f}%")
