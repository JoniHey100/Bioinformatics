#!/usr/bin/env python3
import os
import math
import random
from pathlib import Path
from typing import List, Tuple, Optional
import matplotlib.pyplot as plt
import numpy as np

PROJECT_DIR = r"C:\Users\ionat\Desktop\FACULTA\AN 4\Sem I\Bioinfo\Lab\Project Lab 3"
FASTA_FILENAME = "sequence.fasta"
DNA_SEQUENCE: Optional[str] = None
WINDOW_SIZE = 9
STEP = 1
NA_MOLAR = 0.05
THRESHOLD: Optional[float] = 65.0
PLOT_PNG_NAME = "tm_plot.png"
BARS_PNG_NAME = "tm_above_threshold.png"
CSV_NAME = "tm_values.csv"
VALID_BASES = set("ACGT")

def ensure_project_dir(path_str: str) -> Path:
    p = Path(path_str)
    p.mkdir(parents=True, exist_ok=True)
    return p

def wrap_fasta(seq: str, width: int = 70) -> str:
    return "\n".join(seq[i:i + width] for i in range(0, len(seq), width))

def make_demo_sequence(n: int = 800, gc_fraction: float = 0.5) -> str:
    random.seed(42)
    seq_chars = []
    for _ in range(n):
        if random.random() < gc_fraction:
            seq_chars.append(random.choice("GC"))
        else:
            seq_chars.append(random.choice("AT"))
    return "".join(seq_chars)

def write_fasta(path: Path, seq: str, header: str = "sequence") -> None:
    seq = seq.upper().replace(" ", "").replace("\n", "").replace("\t", "")
    if not seq:
        raise ValueError("DNA sequence is empty.")
    if any(b not in VALID_BASES for b in seq):
        bad = sorted(set(b for b in seq if b not in VALID_BASES))
        raise ValueError(f"Invalid DNA base(s): {', '.join(bad)}. Allowed: A, C, G, T.")
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(f">{header}\n{wrap_fasta(seq)}\n")

def read_fasta_dna(path: Path) -> str:
    parts: List[str] = []
    with open(path, "r", encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line or line.startswith(">"):
                continue
            parts.append(line.upper())
    seq = "".join(parts)
    if not seq:
        raise ValueError("No sequence found in FASTA.")
    return seq

def window_iter(seq: str, k: int, step: int):
    if k <= 0:
        raise ValueError("Window size must be > 0.")
    if step <= 0:
        raise ValueError("Step must be > 0.")
    for i in range(0, len(seq) - k + 1, step):
        yield i, seq[i:i + k]

def tm_simple(window: str) -> float:
    g = window.count("G")
    c = window.count("C")
    a = window.count("A")
    t = window.count("T")
    return 4.0 * (g + c) + 2.0 * (a + t)

def tm_salt_adjusted(window: str, na_molar: float) -> float:
    if na_molar <= 0:
        raise ValueError("[Na+] must be > 0 (M).")
    k = len(window)
    gc_percent = 100.0 * (window.count("G") + window.count("C")) / k
    return 81.5 + 16.6 * math.log10(na_molar) + 0.41 * gc_percent - (600.0 / k)

def valid_dna(window: str) -> bool:
    return all(b in VALID_BASES for b in window)

def sliding_tm(seq: str, k: int, step: int, na_molar: float) -> Tuple[List[int], List[Optional[float]], List[Optional[float]]]:
    positions, svals, tvals = [], [], []
    half = k // 2
    for start, w in window_iter(seq, k, step):
        center = start + half + 1
        positions.append(center)
        if valid_dna(w):
            svals.append(tm_simple(w))
            tvals.append(tm_salt_adjusted(w, na_molar))
        else:
            svals.append(None)
            tvals.append(None)
    return positions, svals, tvals

def min_max(values: List[Optional[float]]) -> Tuple[Optional[float], Optional[float]]:
    nums = [v for v in values if v is not None]
    if not nums:
        return None, None
    return min(nums), max(nums)

def save_csv(positions: List[int], simple_vals: List[Optional[float]], salt_vals: List[Optional[float]], out_csv: Path) -> None:
    import csv
    with open(out_csv, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["position_center_1based", "tm_simple_c", "tm_salt_adjusted_c"])
        for pos, s, t in zip(positions, simple_vals, salt_vals):
            w.writerow([pos, "" if s is None else f"{s:.6f}", "" if t is None else f"{t:.6f}"])
    print(f"CSV saved to: {out_csv}")

def plot_tm_series(positions: List[int], simple_vals: List[Optional[float]], salt_vals: List[Optional[float]],
                   k: int, step: int, na_molar: float, title: str, out_png: Path, threshold: Optional[float] = None) -> None:
    x = np.array(positions)
    y1 = np.ma.masked_invalid(np.array([float(v) if v is not None else np.nan for v in simple_vals]))
    y2 = np.ma.masked_invalid(np.array([float(v) if v is not None else np.nan for v in salt_vals]))
    plt.figure()
    plt.plot(x, y1, label="Tm (simple)")
    plt.plot(x, y2, label=f"Tm (salt-adjusted, [Na+]={na_molar:g} M)")
    if threshold is not None:
        plt.axhline(threshold, linestyle="--", linewidth=1, label=f"Threshold = {threshold:g} °C")
    plt.xlabel("Sequence position (window center, 1-based)")
    plt.ylabel("Temperature (°C)")
    plt.title(f"{title} — window={k}, step={step}")
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(out_png, dpi=150)
    print(f"Plot saved to: {out_png}")
    plt.show()

def intervals_above_threshold(positions: List[int], values: List[Optional[float]], k: int, threshold: float) -> List[Tuple[int, int]]:
    half = k // 2
    intervals: List[Tuple[int, int]] = []
    cur_start: Optional[int] = None
    cur_end: Optional[int] = None
    for center, v in zip(positions, values):
        if v is not None and v >= threshold:
            w_start = center - half
            w_end = center + half
            if cur_start is None:
                cur_start, cur_end = w_start, w_end
            else:
                if w_start <= (cur_end + 1):
                    cur_end = max(cur_end, w_end)
                else:
                    intervals.append((cur_start, cur_end))
                    cur_start, cur_end = w_start, w_end
        else:
            if cur_start is not None:
                intervals.append((cur_start, cur_end))
                cur_start, cur_end = None, None
    if cur_start is not None:
        intervals.append((cur_start, cur_end))
    return intervals

def plot_threshold_bars(positions: List[int], simple_vals: List[Optional[float]], salt_vals: List[Optional[float]],
                        k: int, seq_len: int, threshold: float, out_png: Path) -> None:
    intervals_simple = intervals_above_threshold(positions, simple_vals, k, threshold)
    intervals_salt = intervals_above_threshold(positions, salt_vals, k, threshold)
    def to_spans(intervals: List[Tuple[int, int]]) -> List[Tuple[int, int]]:
        spans = []
        for s, e in intervals:
            s_clamped = max(1, s)
            e_clamped = min(seq_len, e)
            width = max(0, e_clamped - s_clamped + 1)
            if width > 0:
                spans.append((s_clamped, width))
        return spans
    spans_simple = to_spans(intervals_simple)
    spans_salt = to_spans(intervals_salt)
    fig, ax = plt.subplots()
    y_simple = 30
    y_salt = 10
    height = 8
    if spans_simple:
        ax.broken_barh(spans_simple, (y_simple, height), label="Simple ≥ threshold")
    if spans_salt:
        ax.broken_barh(spans_salt, (y_salt, height), label="Salt-adjusted ≥ threshold")
    ax.set_ylim(0, 50)
    ax.set_xlim(1, seq_len)
    ax.set_xlabel("Sequence position (genomic coordinate, 1-based)")
    ax.set_yticks([y_simple + height/2, y_salt + height/2])
    ax.set_yticklabels(["Tm simple", "Tm salt-adj"])
    ax.set_title(f"Regions ≥ {threshold:g} °C (window={k})")
    ax.grid(True)
    ax.legend(loc="upper right")
    fig.tight_layout()
    fig.savefig(out_png, dpi=150)
    print(f"Bars plot saved to: {out_png}")
    plt.show()

def main():
    project = ensure_project_dir(PROJECT_DIR)
    fasta_path = project / FASTA_FILENAME
    if DNA_SEQUENCE is None:
        dna = make_demo_sequence(n=800, gc_fraction=0.5)
        header = "demo_sequence_gc50_len800"
    else:
        dna = DNA_SEQUENCE
        header = "user_sequence"
    write_fasta(fasta_path, dna, header=header)
    print(f"FASTA written to: {fasta_path}")
    seq = read_fasta_dna(fasta_path)
    seq_len = len(seq)
    print(f"Sequence length: {seq_len} bases")
    positions, tms_simple, tms_salt = sliding_tm(seq, k=WINDOW_SIZE, step=STEP, na_molar=NA_MOLAR)
    s_min, s_max = min_max(tms_simple)
    a_min, a_max = min_max(tms_salt)
    print("==== Min/Max (°C) ====")
    print(f"Simple       : min={s_min:.2f}  max={s_max:.2f}" if s_min is not None else "Simple       : N/A")
    print(f"Salt-adjusted: min={a_min:.2f}  max={a_max:.2f}" if a_min is not None else "Salt-adjusted: N/A")
    out_csv = project / CSV_NAME
    save_csv(positions, tms_simple, tms_salt, out_csv)
    out_png = project / PLOT_PNG_NAME
    plot_tm_series(positions, tms_simple, tms_salt, WINDOW_SIZE, STEP, NA_MOLAR,
                   title=f"Tm along {fasta_path.name}", out_png=out_png, threshold=THRESHOLD)
    if THRESHOLD is not None:
        out_bars = project / BARS_PNG_NAME
        plot_threshold_bars(positions, tms_simple, tms_salt, WINDOW_SIZE, seq_len, THRESHOLD, out_bars)

if __name__ == "__main__":
    main()
