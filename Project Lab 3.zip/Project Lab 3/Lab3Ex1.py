#!/usr/bin/env python3
from __future__ import annotations

import argparse
import math
import sys
from dataclasses import dataclass

VALID_BASES = set("ACGT")

@dataclass(frozen=True)
class TmResult:
    length: int
    gc_percent: float
    simple_tm_c: float | None
    salt_tm_c: float | None
    na_molar: float | None

def clean_sequence(seq: str) -> str:
    seq = (seq or "").upper().replace(" ", "").replace("\n", "").replace("\t", "")
    if not seq:
        raise ValueError("Empty DNA sequence.")
    if any(b not in VALID_BASES for b in seq):
        bad = sorted(set(b for b in seq if b not in VALID_BASES))
        raise ValueError(f"Invalid DNA base(s): {', '.join(bad)}. Allowed: A, C, G, T.")
    return seq

def tm_simple(seq: str) -> float:
    g = seq.count("G")
    c = seq.count("C")
    a = seq.count("A")
    t = seq.count("T")
    return 4.0 * (g + c) + 2.0 * (a + t)

def tm_salt_adjusted(seq: str, na_molar: float) -> float:
    if na_molar <= 0:
        raise ValueError("[Na+] must be > 0 (in molar).")
    length = len(seq)
    gc_percent = 100.0 * (seq.count("G") + seq.count("C")) / length
    return 81.5 + 16.6 * math.log10(na_molar) + 0.41 * gc_percent - (600.0 / length)

def compute_tm(seq: str, formula: str, na_molar: float) -> TmResult:
    seq = clean_sequence(seq)
    length = len(seq)
    gc_percent = 100.0 * (seq.count("G") + seq.count("C")) / length

    simple_val = tm_simple(seq) if formula in ("simple", "both") else None
    salt_val = tm_salt_adjusted(seq, na_molar) if formula in ("salt", "both") else None

    return TmResult(
        length=length,
        gc_percent=gc_percent,
        simple_tm_c=simple_val,
        salt_tm_c=salt_val,
        na_molar=na_molar if salt_val is not None else None,
    )

def main(argv=None):
    parser = argparse.ArgumentParser(description="Calculate DNA melting temperature (Tm).")
    parser.add_argument("sequence", help="DNA sequence (A/C/G/T)")
    parser.add_argument(
        "--formula",
        choices=["simple", "salt", "both"],
        default="both",
        help="Which formula to use (default: both).",
    )
    parser.add_argument(
        "--na",
        type=float,
        default=0.05,
        help="[Na+] in molar for the salt-adjusted formula (default: 0.05 = 50 mM).",
    )

    args = parser.parse_args(argv)

    try:
        result = compute_tm(args.sequence, args.formula, args.na)
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

    print(f"Sequence length: {result.length} nt")
    print(f"GC content: {result.gc_percent:.2f}%")
    if result.simple_tm_c is not None:
        print(f"Tm (simple, 4*GC + 2*AT): {result.simple_tm_c:.2f} °C")
    if result.salt_tm_c is not None:
        print(f"Tm (salt-adjusted; [Na+]={result.na_molar:g} M): {result.salt_tm_c:.2f} °C")

if __name__ == "__main__":
    sequence = "ATGCTAGTCGC"
    formula = "both"
    na = 0.05

    result = compute_tm(sequence, formula, na)

    if result.simple_tm_c is not None:
        print(f"Simple formula Tm: {result.simple_tm_c:.2f} °C")
    if result.salt_tm_c is not None:
        print(f"Salt formula Tm: {result.salt_tm_c:.2f} °C")


