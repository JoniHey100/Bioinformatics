#!/usr/bin/env python3

import math
import random
from pathlib import Path
from typing import List, Tuple, Optional

import matplotlib.pyplot as plt

PROJECT_DIR = r"C:\Users\ionat\Desktop\FACULTA\AN 4\Sem I\Bioinfo\Lab\Project Lab 3"

FASTA_FILENAME = "sequence.fasta"


DNA_SEQUENCE: Optional[str] = None

WINDOW_SIZE = 9 
STEP = 1
NA_MOLAR = 0.05 


PLOT_PNG_NAME = "tm_plot.png"
CSV_NAME = "tm_values.csv"


VALID_BASES = set("ACGT")


def ensure_project_dir(path_str: str) -> Path:
    p = Path(path_str)
    p.mkdir(parents=True, exist_ok=True)
    return p


def wrap_fasta(seq: str, width: int = 70) -> str:
    return "\n".join(seq[i:i + width] for i in range(0, len(seq), width))


def make_demo_sequence(n: int = 800, gc_fraction: float = 0.5) -> str:
    random.seed(42)
    gc_letters = "GC"
    at_letters = "AT"
    seq_chars = []
    for _ in range(n):
        if random.random() < gc_fraction:
            seq_chars.append(random.choice(gc_letters))
        else:
            seq_chars.append(random.choice(at_letters))
    return "".join(seq_chars)


def write_fasta(path: Path, seq: str, header: str = "sequence") -> None:
    seq = seq.upper().replace(" ", "").replace("\n", "").replace("\t", "")
    if not seq:
        raise ValueError("DNA sequence is empty.")
    
    if any(b not in VALID_BASES for b in seq):
        bad = sorted(set(b for b in seq if b not in VALID_BASES))
        raise ValueError(f"Invalid DNA base(s) found: {', '.join(bad)}. Allowed: A, C, G, T.")
    fasta_text = f">{header}\n{wrap_fasta(seq)}\n"
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(fasta_text)


def read_fasta_dna(path: Path) -> str:
    parts: List[str] = []
    with open(path, "r", encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line or line.startswith(">"):
                continue
            parts.append(line.upper())
    seq = "".join(parts)
    if not seq:
        raise ValueError("No sequence found in FASTA.")
    return seq


def window_iter(seq: str, k: int, step: int):
    if k <= 0:
        raise ValueError("Window size must be > 0.")
    if step <= 0:
        raise ValueError("Step must be > 0.")
    for i in range(0, len(seq) - k + 1, step):
        yield i, seq[i:i + k]


def tm_simple(window: str) -> float:
    g = window.count("G")
    c = window.count("C")
    a = window.count("A")
    t = window.count("T")
    return 4.0 * (g + c) + 2.0 * (a + t)


def tm_salt_adjusted(window: str, na_molar: float) -> float:
    if na_molar <= 0:
        raise ValueError("[Na+] must be > 0 (in molar).")
    length = len(window)
    gc_percent = 100.0 * (window.count("G") + window.count("C")) / length
    return 81.5 + 16.6 * math.log10(na_molar) + 0.41 * gc_percent - (600.0 / length)


def valid_dna(window: str) -> bool:
    return all(b in VALID_BASES for b in window)


def sliding_tm(seq: str, k: int, step: int, na_molar: float
               ) -> Tuple[List[int], List[Optional[float]], List[Optional[float]]]:
    positions: List[int] = []
    simple_vals: List[Optional[float]] = []
    salt_vals: List[Optional[float]] = []
    half = k // 2

    for start, w in window_iter(seq, k, step):
        positions.append(start + half + 1)  # center position, 1-based
        if valid_dna(w):
            simple_vals.append(tm_simple(w))
            salt_vals.append(tm_salt_adjusted(w, na_molar))
        else:
            simple_vals.append(None)
            salt_vals.append(None)
    return positions, simple_vals, salt_vals


def plot_tm_series(positions: List[int],
                   simple_vals: List[Optional[float]],
                   salt_vals: List[Optional[float]],
                   k: int, step: int, na_molar: float,
                   title: str, out_png: Path) -> None:
    import numpy as np

    x = np.array(positions)
    y1 = np.ma.masked_invalid(np.array([float(v) if v is not None else np.nan for v in simple_vals]))
    y2 = np.ma.masked_invalid(np.array([float(v) if v is not None else np.nan for v in salt_vals]))

    plt.figure()
    plt.plot(x, y1, label="Tm (simple: 4·GC + 2·AT)")
    plt.plot(x, y2, label=f"Tm (salt-adjusted, [Na+]={na_molar:g} M)")
    plt.xlabel("Sequence position (window center, 1-based)")
    plt.ylabel("Temperature (°C)")
    plt.title(f"{title} — window={k}, step={step}")
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(out_png, dpi=150)
    print(f"Plot saved to: {out_png}")
    plt.show()


def save_csv(positions: List[int],
             simple_vals: List[Optional[float]],
             salt_vals: List[Optional[float]],
             out_csv: Path) -> None:
    import csv
    with open(out_csv, "w", newline="", encoding="utf-8") as fh:
        writer = csv.writer(fh)
        writer.writerow(["position_center_1based", "tm_simple_c", "tm_salt_adjusted_c"])
        for pos, s, t in zip(positions, simple_vals, salt_vals):
            writer.writerow([pos, "" if s is None else f"{s:.6f}", "" if t is None else f"{t:.6f}"])
    print(f"CSV saved to: {out_csv}")


def main():
    project = ensure_project_dir(PROJECT_DIR)
    fasta_path = project / FASTA_FILENAME
    if DNA_SEQUENCE is None:
        dna = make_demo_sequence(n=800, gc_fraction=0.5)
        header = "demo_sequence_gc50_len800"
    else:
        dna = DNA_SEQUENCE
        header = "user_sequence"
    write_fasta(fasta_path, dna, header=header)
    print(f"FASTA written to: {fasta_path}")

  
    seq = read_fasta_dna(fasta_path)
    print(f"Sequence length: {len(seq)} bases")

    positions, tms_simple, tms_salt = sliding_tm(seq, k=WINDOW_SIZE, step=STEP, na_molar=NA_MOLAR)

    out_csv = project / CSV_NAME
    save_csv(positions, tms_simple, tms_salt, out_csv)

    out_png = project / PLOT_PNG_NAME
    plot_tm_series(positions, tms_simple, tms_salt, WINDOW_SIZE, STEP, NA_MOLAR,
                   title=f"Tm along {fasta_path.name}", out_png=out_png)


if __name__ == "__main__":
    main()
