# -*- coding: utf-8 -*-

import random

def generate_random_dna(length):
    return "".join(random.choice("ACGT") for _ in range(length))

class Transposon:
    def __init__(self, name, internal_seq, ir_seq):
        self.name = name
        self.ir_seq = ir_seq
        self.ir_seq_rev = ir_seq[::-1] 
        self.internal = internal_seq
        self.full_sequence = self.ir_seq + self.internal + self.ir_seq_rev
        self.length = len(self.full_sequence)

def insert_transposon(host_dna, transposon, position):
    tsd_len = 4 
    
    if position < tsd_len or position > len(host_dna) - tsd_len:
        position = len(host_dna) // 2
        
    tsd_seq = host_dna[position:position+tsd_len]
    
    print(f"--- Inserting {transposon.name} at index {position} ---")
    print(f"    Target Site Duplication (TSD) created: {tsd_seq}")
    
    left_flank = host_dna[:position+tsd_len]
    right_flank = host_dna[position+tsd_len:]
    
    new_dna = host_dna[:position] + tsd_seq + transposon.full_sequence + tsd_seq + host_dna[position+tsd_len:]
    
    return new_dna

def detect_transposons(genome, library):
    print("\n" + "="*40)
    print("RUNNING DETECTION ALGORITHM")
    print("="*40)
    
    results = []

    for te in library:
        start_idx = genome.find(te.full_sequence)
        
        if start_idx != -1:
            end_idx = start_idx + len(te.full_sequence)
            results.append({
                "name": te.name,
                "status": "Intact",
                "start": start_idx,
                "end": end_idx,
                "details": "Found contiguous sequence."
            })
        else:
            head_seq = te.ir_seq + te.internal[:5]
            tail_seq = te.internal[-5:] + te.ir_seq_rev
            
            head_pos = genome.find(head_seq)
            tail_pos = genome.find(tail_seq)
            
            if head_pos != -1 and tail_pos != -1:
                tail_end_pos = tail_pos + len(tail_seq)
                
                observed_len = tail_end_pos - head_pos
                gap_size = observed_len - te.length
                
                if gap_size > 0:
                    results.append({
                        "name": te.name,
                        "status": "Intersected/Nested",
                        "start": head_pos,
                        "end": tail_end_pos,
                        "details": f"TE was split! Gap of {gap_size}bp detected inside."
                    })
                else:
                     results.append({
                        "name": te.name,
                        "status": "Fragmented",
                        "start": head_pos,
                        "end": tail_end_pos,
                        "details": "Found ends, but length is inconsistent."
                    })
            else:
                 results.append({
                        "name": te.name,
                        "status": "Not Found",
                        "details": "Significant fragments missing."
                    })

    return results

te_library = [
    Transposon("Tn_Alpha", "CCCCCCCCCC", "TTTT"),
    Transposon("Tn_Beta",  "GGGGGGGGGG", "AAAA"),
    Transposon("Tn_Gamma", "ATATATATAT", "CGCG")
]

genome = generate_random_dna(300)
print(f"Original Host DNA Length: {len(genome)}bp")

genome = insert_transposon(genome, te_library[0], 50)
genome = insert_transposon(genome, te_library[1], 200)
genome = insert_transposon(genome, te_library[2], 60)

print(f"Final Mutated Genome Length: {len(genome)}bp")

detections = detect_transposons(genome, te_library)

print("\nDetection Report:")
print(f"{'TE Name':<10} | {'Status':<20} | {'Position (Start-End)':<20} | {'Notes'}")
print("-" * 80)
for res in detections:
    pos_str = f"{res.get('start', 'N/A')}-{res.get('end', 'N/A')}"
    print(f"{res['name']:<10} | {res['status']:<20} | {pos_str:<20} | {res['details']}")

print("-" * 80)
