import time

def get_reverse_complement(seq):
    complement = {'A': 'T', 'T': 'A', 'C': 'G', 'G': 'C', 'N': 'N'}
    return "".join(complement.get(base, base) for base in reversed(seq))

def read_fasta(file_path):
    with open(file_path, 'r') as f:
        header = None
        sequence = []
        for line in f:
            line = line.strip()
            if not line:
                continue
            if line.startswith(">"):
                if header:
                    yield header, "".join(sequence)
                header = line[1:]
                sequence = []
            else:
                sequence.append(line)
        if header:
            yield header, "".join(sequence)

def find_inverted_repeats(sequence, min_k=4, max_k=6, min_gap=100, max_gap=5000):
    candidates = []
    seq_len = len(sequence)
    sequence = sequence.upper()

    for k in range(min_k, max_k + 1):
        kmer_positions = {}
        
        for i in range(seq_len - k + 1):
            kmer = sequence[i : i+k]
            if 'N' in kmer:
                continue
                
            if kmer not in kmer_positions:
                kmer_positions[kmer] = []
            kmer_positions[kmer].append(i)

        checked_kmers = set()

        for kmer, start_indices in kmer_positions.items():
            if kmer in checked_kmers:
                continue
            
            rc_kmer = get_reverse_complement(kmer)
            
            if rc_kmer in kmer_positions:
                end_indices = kmer_positions[rc_kmer]
                
                for s_idx in start_indices:
                    for e_idx in end_indices:
                        if e_idx > s_idx:
                            dist = e_idx - (s_idx + k)
                            
                            if min_gap <= dist <= max_gap:
                                total_len = (e_idx + k) - s_idx
                                
                                candidates.append({
                                    'start': s_idx + 1,
                                    'end': e_idx + k,
                                    'length': total_len,
                                    'ir_seq': kmer,
                                    'rc_seq': rc_kmer,
                                    'ir_len': k,
                                    'gap_size': dist
                                })
            
            checked_kmers.add(kmer)

    candidates.sort(key=lambda x: x['start'])
    return candidates

def analyze_overlaps(candidates):
    results = []
    for i, current in enumerate(candidates):
        status = "Distinct"
        
        for j, other in enumerate(candidates):
            if i == j:
                continue
            
            if current['start'] > other['start'] and current['end'] < other['end']:
                status = f"Nested inside TE at {other['start']}"
                break
            
            elif (current['start'] < other['end'] and current['start'] > other['start']) or \
                 (current['end'] > other['start'] and current['end'] < other['end']):
                status = f"Overlaps with TE at {other['start']}"
                break
        
        current['status'] = status
        results.append(current)
    return results

def main():
    input_file = "bacteria.fasta"
    
    print(f"--- Processing {input_file} ---")
    print("Constraints: IR 4-6bp | Spacing 100-5000bp")
    print("----------------------------------------------------")

    try:
        for header, sequence in read_fasta(input_file):
            genome_id = header.split()[0]
            print(f"\nAnalyzing Genome: {genome_id} (Length: {len(sequence)} bp)")
            
            start_time = time.time()
            
            raw_candidates = find_inverted_repeats(sequence)
            final_candidates = analyze_overlaps(raw_candidates)
            
            elapsed = time.time() - start_time
            
            if not final_candidates:
                print("No transposons detected matching criteria.")
            else:
                print(f"Found {len(final_candidates)} potential elements in {elapsed:.2f}s")
                print(f"{'Start':<10} {'End':<10} {'Length':<8} {'IR Seq':<10} {'Status'}")
                print("-" * 60)
                
                limit = 50 
                for i, te in enumerate(final_candidates):
                    if i >= limit:
                        print(f"... and {len(final_candidates) - limit} more.")
                        break
                    print(f"{te['start']:<10} {te['end']:<10} {te['length']:<8} {te['ir_seq']:<10} {te['status']}")

    except FileNotFoundError:
        print(f"Error: File '{input_file}' not found. Please upload bacteria.fasta.")

if __name__ == "__main__":
    main()
