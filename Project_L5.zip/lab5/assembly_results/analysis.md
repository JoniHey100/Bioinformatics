# Analysis of Simulated Assembly Time vs. C+G Content

![Assembly Plot](assembly_plot.png)


## Overall Analysis and Conclusion

After running the experiment, the data in the plot (`assembly_plot.png`) reveals the primary factor driving assembly time.

### 1. The C+G Content (X-Axis) Has No Correlation

The points are scattered widely across the X-axis.

### 2. Genome Size / Sample Count (Y-Axis) is the Key

As the simulated genome size increases, the assembly time increases dramatically.

**Final Conclusion:** The total genome size, which dictates the number of samples, is the dominant factor determining assembly time.


## Individual Run Data

### Human papillomavirus 16 (HPV-16)

* **Simulated Genome Size:** 1000 bp
* **C+G Content:** 41.18%
* **Samples Generated (8x coverage):** 64
* **Assembly Time:** 16.15 ms
* **Assembly Result:** Rebuilt 493 bp before stopping.

### HIV-1

* **Simulated Genome Size:** 1200 bp
* **C+G Content:** 41.55%
* **Samples Generated (8x coverage):** 76
* **Assembly Time:** 1.04 ms
* **Assembly Result:** Rebuilt 102 bp before stopping.

### Zika virus

* **Simulated Genome Size:** 1300 bp
* **C+G Content:** 46.09%
* **Samples Generated (8x coverage):** 83
* **Assembly Time:** 20.92 ms
* **Assembly Result:** Rebuilt 559 bp before stopping.

### Influenza A virus

* **Simulated Genome Size:** 1500 bp
* **C+G Content:** 41.38%
* **Samples Generated (8x coverage):** 96
* **Assembly Time:** 13.19 ms
* **Assembly Result:** Rebuilt 278 bp before stopping.

### Ebola virus

* **Simulated Genome Size:** 2000 bp
* **C+G Content:** 40.87%
* **Samples Generated (8x coverage):** 128
* **Assembly Time:** 122.93 ms
* **Assembly Result:** Rebuilt 1941 bp before stopping.

### SARS-CoV-2

* **Simulated Genome Size:** 3000 bp
* **C+G Content:** 38.02%
* **Samples Generated (8x coverage):** 192
* **Assembly Time:** 229.03 ms
* **Assembly Result:** Rebuilt 2255 bp before stopping.

### Human alphaherpesvirus 1 (HSV-1)

* **Simulated Genome Size:** 7500 bp
* **C+G Content:** 68.54%
* **Samples Generated (8x coverage):** 480
* **Assembly Time:** 376.70 ms
* **Assembly Result:** Rebuilt 1204 bp before stopping.

### Bacteriophage T4

* **Simulated Genome Size:** 8000 bp
* **C+G Content:** 35.34%
* **Samples Generated (8x coverage):** 512
* **Assembly Time:** 350.32 ms
* **Assembly Result:** Rebuilt 1045 bp before stopping.

### Mimivirus

* **Simulated Genome Size:** 15000 bp
* **C+G Content:** 28.10%
* **Samples Generated (8x coverage):** 960
* **Assembly Time:** 4932.60 ms
* **Assembly Result:** Rebuilt 9211 bp before stopping.

### Pandoravirus salinus

* **Simulated Genome Size:** 20000 bp
* **C+G Content:** 64.57%
* **Samples Generated (8x coverage):** 1280
* **Assembly Time:** 12006.99 ms
* **Assembly Result:** Rebuilt 17761 bp before stopping.
