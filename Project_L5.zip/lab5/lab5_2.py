# -*- coding: utf-8 -*-

import random
import time
import os
import matplotlib.pyplot as plt

def calculate_cg_percent(sequence):
    total_len = len(sequence)
    if total_len == 0:
        return 0
    
    c_count = sequence.count('C')
    g_count = sequence.count('G')
    return (c_count + g_count) / total_len * 100

def generate_mock_genome(length, cg_percent):
    target_cg_count = int(length * (cg_percent / 100))
    target_at_count = length - target_cg_count
    
    genome = (['C'] * (target_cg_count // 2) +
              ['G'] * (target_cg_count - (target_cg_count // 2)) +
              ['A'] * (target_at_count // 2) +
              ['T'] * (target_at_count - (target_at_count // 2)))
    
    genome.extend(['A', 'T', 'C', 'G'])
    
    while len(genome) < length:
        genome.append(random.choice(['A', 'T', 'C', 'G']))
        
    random.shuffle(genome)
    
    repeat_seq = "".join(random.choices(genome, k=50))
    for _ in range(length // 1000):
        insert_pos = random.randint(0, len(genome) - 50)
        genome.insert(insert_pos, repeat_seq)

    return "".join(genome)

def take_samples(sequence, num_samples, min_len, max_len):
    samples = []
    seq_len = len(sequence)
    
    for _ in range(num_samples):
        sample_len = random.randint(min_len, max_len)
        max_start_index = seq_len - sample_len
        if max_start_index <= 0:
            continue
            
        start_index = random.randint(0, max_start_index)
        samples.append(sequence[start_index : start_index + sample_len])
        
    return samples

def rebuild_sequence_greedy(samples, min_overlap):
    if not samples:
        return ""

    rebuilt_sequence = samples[0]
    used_indices = {0}
    
    while True:
        best_overlap_len = -1
        best_sample_index = -1
        search_tail = rebuilt_sequence[-150:] 
        
        for i in range(len(samples)):
            if i in used_indices:
                continue
                
            current_sample = samples[i]
            
            for overlap_len in range(min(len(search_tail), len(current_sample)), min_overlap - 1, -1):
                if search_tail.endswith(current_sample[:overlap_len]):
                    if overlap_len > best_overlap_len:
                        best_overlap_len = overlap_len
                        best_sample_index = i
                    break 
        
        if best_sample_index != -1:
            best_sample = samples[best_sample_index]
            rebuilt_sequence += best_sample[best_overlap_len:]
            used_indices.add(best_sample_index)
        else:
            break
            
    return rebuilt_sequence

def run_experiment():
    virus_database = [
        ('Human papillomavirus 16 (HPV-16)', 40.7, 1000),
        ('HIV-1', 41.8, 1200),
        ('Zika virus', 46.2, 1300),
        ('Influenza A virus', 41.0, 1500),
        ('Ebola virus', 40.9, 2000),
        ('SARS-CoV-2', 38.0, 3000),
        ('Human alphaherpesvirus 1 (HSV-1)', 68.3, 7500),
        ('Bacteriophage T4', 35.4, 8000),
        ('Mimivirus', 28.3, 15000),
        ('Pandoravirus salinus', 64.7, 20000),
    ]
    
    MIN_SAMPLE_LEN = 100
    MAX_SAMPLE_LEN = 150
    AVG_SAMPLE_LEN = (MIN_SAMPLE_LEN + MAX_SAMPLE_LEN) // 2
    MIN_OVERLAP = 10
    COVERAGE = 8
    
    plot_data = []
    analysis_lines = ["# Analysis of Simulated Assembly Time vs. C+G Content\n\n"]
    
    print("--- Starting Assembly Experiment ---")
    
    for name, real_cg, sim_length in virus_database:
        print(f"\nProcessing: {name} (Simulated length: {sim_length} bp)")
        genome = generate_mock_genome(sim_length, real_cg)
        cg_percent = calculate_cg_percent(genome)
        
        num_samples = int((sim_length * COVERAGE) / AVG_SAMPLE_LEN)
        samples = take_samples(genome, num_samples, MIN_SAMPLE_LEN, MAX_SAMPLE_LEN)
        print(f"   Generated {num_samples} samples.")
        
        random.shuffle(samples)
        
        start_time = time.perf_counter()
        rebuilt_sequence = rebuild_sequence_greedy(samples, MIN_OVERLAP)
        end_time = time.perf_counter()
        
        time_ms = (end_time - start_time) * 1000
        print(f"   Assembly Time: {time_ms:.2f} ms")
        
        plot_data.append({
            'name': name,
            'x_cg': cg_percent,
            'y_time': time_ms,
            'size': sim_length,
            'samples': num_samples
        })
        
        analysis_lines.append(f"### {name}\n")
        analysis_lines.append(f"* **Simulated Genome Size:** {sim_length} bp")
        analysis_lines.append(f"* **C+G Content:** {cg_percent:.2f}%")
        analysis_lines.append(f"* **Samples Generated (8x coverage):** {num_samples}")
        analysis_lines.append(f"* **Assembly Time:** {time_ms:.2f} ms")
        analysis_lines.append(f"* **Assembly Result:** Rebuilt {len(rebuilt_sequence)} bp before stopping.\n")

    print("\n--- Experiment Complete ---")
    return plot_data, analysis_lines

def create_plot(plot_data):
    x_vals = [d['x_cg'] for d in plot_data]
    y_vals = [d['y_time'] for d in plot_data]
    labels = [f"{d['name']}\n({d['size']} bp)" for d in plot_data]
    
    plt.figure(figsize=(14, 9))
    scatter = plt.scatter(
        x_vals, y_vals,
        s=150,
        c=[d['size'] for d in plot_data],
        cmap='viridis',
        alpha=0.7
    )
    
    plt.title('Simulated Assembly Time vs. C+G Content', fontsize=18)
    plt.xlabel('C+G Content (%)', fontsize=14)
    plt.ylabel('Assembly Time (ms)', fontsize=14)
    
    for i, label in enumerate(labels):
        plt.annotate(
            label.split('\n')[0],
            (x_vals[i], y_vals[i]),
            textcoords="offset points",
            xytext=(0, 10),
            ha='center',
            fontsize=9
        )
    
    plt.grid(True, linestyle='--', alpha=0.5)
    plt.colorbar(scatter, label='Simulated Genome Size (bp)')
    
    filepath = os.path.join("assembly_results", "assembly_plot.png")
    plt.savefig(filepath)
    print(f"Plot saved to: {filepath}")

def write_analysis(analysis_lines, plot_data):
    header = analysis_lines[0]
    results = "\n".join(analysis_lines[1:])
    
    conclusion = """
## Overall Analysis and Conclusion

After running the experiment, the data in the plot (`assembly_plot.png`) reveals the primary factor driving assembly time.

### 1. The C+G Content (X-Axis) Has No Correlation

The points are scattered widely across the X-axis.

### 2. Genome Size / Sample Count (Y-Axis) is the Key

As the simulated genome size increases, the assembly time increases dramatically.

**Final Conclusion:** The total genome size, which dictates the number of samples, is the dominant factor determining assembly time.
"""
    
    filepath = os.path.join("assembly_results", "analysis.md")
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(header)
        f.write("![Assembly Plot](assembly_plot.png)\n\n")
        f.write(conclusion)
        f.write("\n\n## Individual Run Data\n\n")
        f.write(results)
        
    print(f"Analysis file saved to: {filepath}")

def main():
    try:
        os.makedirs("assembly_results", exist_ok=True)
    except OSError as e:
        print(f"Error creating directory: {e}")
        return

    plot_data, analysis_lines = run_experiment()
    
    if plot_data:
        create_plot(plot_data)
        write_analysis(analysis_lines, plot_data)
        print("\n✅ Success! All files are in the 'assembly_results' folder.")
    else:
        print("Experiment failed to run.")

if __name__ == "__main__":
    main()
