# -*- coding: utf-8 -*-
"""
Created on Thu Nov  6 15:24:23 2025

@author: ionat
"""

import random
import matplotlib.pyplot as plt
import numpy as np
import re

file_path = 'covid.fasta'

sequence_lines = []
full_genome = ""
genome_length = 0

try:
    with open(file_path, 'r') as f:
        for line in f:
            if not line.startswith('>'):
                sequence_lines.append(line.strip())
    
    full_genome = "".join(sequence_lines)
    genome_length = len(full_genome)
    
    if genome_length == 0:
        print("Warning: Genome sequence is empty. Check FASTA file.")
        genome_length = 30000 

except Exception as e:
    print(f"Error reading file: {e}. Using a dummy length.")
    genome_length = 30000

print(f"Parsed genome. Total length: {genome_length} bp")


fragment_lengths = []
for _ in range(10):
    length = random.randint(100, 3000)
    fragment_lengths.append(length)

fragment_lengths.sort(reverse=True)
print(f"Generated 10 random fragment lengths (bp): {fragment_lengths}")

ladder_bands = [10000, 8000, 6000, 5000, 4000, 3000, 2500, 2000, 1500, 1000, 750, 500, 250, 100]

ladder_labels = {
    3000: '3000 bp -',
    1500: '1500 bp -',
    500: '500 bp -'
}

fig, ax = plt.subplots(figsize=(4, 7))
fig.patch.set_facecolor('black')
ax.set_facecolor('black')

ax.set_xlim(0, 1)
ax.set_ylim(50, 12000) 
ax.set_yscale('log') 
ax.invert_yaxis() 

lane_width = 0.3
ladder_x = 0.3 
sample_x = 0.7 
well_y_start = 11000 
well_height = 1000

well_patch_ladder = plt.Rectangle((ladder_x - lane_width/2, well_y_start), 
                                  lane_width, well_height, 
                                  facecolor='#555555', 
                                  edgecolor='#888888')
ax.add_patch(well_patch_ladder)

well_patch_sample = plt.Rectangle((sample_x - lane_width/2, well_y_start), 
                                  lane_width, well_height, 
                                  facecolor='#555555', 
                                  edgecolor='#888888')
ax.add_patch(well_patch_sample)


for band_size in ladder_bands:
    lw = 2 
    if band_size == 3000 or band_size == 1000:
        lw = 4 
        
    ax.plot([ladder_x - lane_width/2, ladder_x + lane_width/2], 
            [band_size, band_size], 
            color='white', 
            linewidth=lw, 
            solid_capstyle='butt') 

for frag_len in fragment_lengths:
    ax.plot([sample_x - lane_width/2, sample_x + lane_width/2], 
            [frag_len, frag_len], 
            color='white', 
            linewidth=3, 
            solid_capstyle='butt')

for band_size, label_text in ladder_labels.items():
    ax.text(ladder_x - lane_width/2 - 0.05,
            band_size,                    
            label_text,                  
            color='white', 
            fontsize=12, 
            fontfamily='sans-serif',
            ha='right',
            va='center')

ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)
ax.spines['bottom'].set_visible(False)
ax.spines['left'].set_visible(False)
ax.get_xaxis().set_ticks([])
ax.get_yaxis().set_ticks([])

plt.tight_layout()
plt.savefig('Screenshot1.png', dpi=150)

